export const LOAD_SUCCESS = 'LOAD_SUCCESS';
export const ADD_CONSTRUCTOR = 'ADD_CONSTRUCTOR';
export const DELETE_CONSTRUCTOR = 'DELETE_CONSTRUCTOR';
export const ADD_BUN = 'ADD_BUN';
export const UPDATE_CONSTRUCTOR = 'UPDATE_CONSTRUCTOR';
export const ADD_ORDER = 'ADD_ORDER';
export const DELETE_ORDER = 'DELETE_ORDER';
export const SHOW_ITEM = 'SHOW_ITEM';
export const HIDE_ITEM = 'HIDE_ITEM';
export const ADD_OREDER_BUN = 'HIDE_ITEM';


