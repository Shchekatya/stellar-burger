const img = <svg width="107" height="102" viewBox="0 0 107 102" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fillRule="evenodd" clipRule="evenodd" d="M8.36637 37.3873C2.54454 45.5044 2.54455 56.4957 8.36637 64.6127L28.3336 92.4518C34.1554 100.569 44.4748 103.965 53.8947 100.865L86.2023 90.2313C95.6223 87.1309 102 78.2387 102 68.2055V33.7945C102 23.7612 95.6222 14.8691 86.2023 11.7687L53.8947 1.13508C44.4748 -1.96536 34.1554 1.43114 28.3336 9.54819L8.36637 37.3873Z" fill="url(#paint0_radial_311_23)" fillOpacity="0.25"/>
<path fillRule="evenodd" clipRule="evenodd" d="M103.944 39.453C108.019 46.5983 108.019 55.4017 103.944 62.547L88.5996 89.453C84.5247 96.5983 76.994 101 68.8442 101H38.1558C30.006 101 22.4753 96.5983 18.4004 89.453L3.05617 62.547C-1.01872 55.4017 -1.01872 46.5983 3.05617 39.453L18.4004 12.547C22.4753 5.40169 30.006 1 38.1558 1L68.8442 1C76.994 1 84.5247 5.40169 88.5996 12.547L103.944 39.453Z" fill="url(#paint1_radial_311_23)" fillOpacity="0.25"/>
<path fillRule="evenodd" clipRule="evenodd" d="M43.9249 20.9109C49.3362 17.0297 56.6638 17.0297 62.0751 20.9109L80.6345 34.2224C86.0459 38.1036 88.3102 44.9832 86.2433 51.2632L79.1542 72.8016C77.0873 79.0815 71.1592 83.3333 64.4703 83.3333H41.5296C34.8408 83.3333 28.9127 79.0815 26.8458 72.8016L19.7567 51.2632C17.6898 44.9832 19.9541 38.1036 25.3655 34.2224L43.9249 20.9109Z" fill="url(#paint2_radial_311_23)" fillOpacity="0.25"/>
<path fillRule="evenodd" clipRule="evenodd" d="M73.3122 37.5959C74.1999 38.4172 74.2327 39.7806 73.3852 40.641L50.0519 64.3333C49.6272 64.7646 49.0371 65.0059 48.422 64.9999C47.8069 64.9939 47.222 64.741 46.8063 64.3016L34.5841 51.3785C33.7548 50.5016 33.8159 49.1392 34.7206 48.3354C35.6253 47.5316 37.031 47.5908 37.8604 48.4677L48.4773 59.6934L70.1703 37.6667C71.0177 36.8062 72.4244 36.7745 73.3122 37.5959Z" fill="#F2F2F3"/>
<defs>
<radialGradient id="paint0_radial_311_23" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(53 51) rotate(-46.1458) scale(70.7248 53.2019)">
<stop stopColor="#801AB3" stopOpacity="0"/>
<stop offset="1" stopColor="#4C4CFF"/>
</radialGradient>
<radialGradient id="paint1_radial_311_23" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(53.5 51) rotate(-43.0632) scale(73.2274 55.0025)">
<stop stopColor="#801AB3" stopOpacity="0"/>
<stop offset="1" stopColor="#4C4CFF"/>
</radialGradient>
<radialGradient id="paint2_radial_311_23" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(53 50.6667) rotate(136.146) scale(47.1499 35.4679)">
<stop stopColor="#801AB3" stopOpacity="0"/>
<stop offset="1" stopColor="#4C4CFF" stopOpacity="0.5"/>
</radialGradient>
</defs>
</svg>

export default img