export const api = "https://norma.nomoreparties.space/api/ingredients";
export const postOrder = "https://norma.nomoreparties.space/api/orders";
