import {createContext} from "react";

export const IngredientContext = createContext(); 